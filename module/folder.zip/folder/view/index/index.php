<div id="dirindex">
    <article>
        <h1><?php echo $this->getData(['module', $this->getUrl(0), 'title']);?></h1>
        <?php echo $module::$folders; ?>
    </article>
</div>